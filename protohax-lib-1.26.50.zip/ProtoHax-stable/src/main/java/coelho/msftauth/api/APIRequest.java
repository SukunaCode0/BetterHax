package coelho.msftauth.api;

import coelho.msftauth.util.GsonUtil;
import com.google.common.io.ByteStreams;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import org.apache.http.Header;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;

import java.lang.reflect.Proxy;
import java.nio.charset.StandardCharsets;

public abstract class APIRequest<R> {

	public R request() throws Exception {
		RequestConfig clientConfig = RequestConfig.custom()
				.setConnectionRequestTimeout(10_000)
				.setConnectTimeout(10_000)
				.setSocketTimeout(10_000)
				.build();
		try (CloseableHttpClient client = HttpClients.custom().setDefaultRequestConfig(clientConfig).build()) {
			HttpUriRequest request;
			if (this.getRequestEncoding() != null) {
				HttpPost post = new HttpPost(this.getHttpURL());
				this.getRequestEncoding().encode(post, this);
				request = post;
			} else {
				request = new HttpGet(this.getHttpURL());
			}
			if (this.getHttpAuthorization() != null) {
				request.setHeader("Authorization", this.getHttpAuthorization());
			}
			this.applyHeader(request);

			try (CloseableHttpResponse response = client.execute(request)) {
				if (response.getStatusLine().getStatusCode() != 200) {
					try {
						System.out.println(EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8));
					} catch (Exception ignore) {
					}
					throw new IllegalStateException("status code: " + response.getStatusLine().getStatusCode());
				}
				R decoded = this.getResponseEncoding().decode(response, this.getResponseClass());
				if (decoded instanceof APIResponseExt) {
					((APIResponseExt) decoded).applyResponse(response);
				}
				return decoded;
			}
		}
	}

	public void applyHeader(HttpRequest request) {

	}

	public R request(OkHttpClient client) throws Exception {
		HttpUriRequest apacheReq;
		if (this.getRequestEncoding() != null) {
			HttpPost post = new HttpPost(this.getHttpURL());
			this.getRequestEncoding().encode(post, this);
			apacheReq = post;
		} else {
			apacheReq = new HttpGet(this.getHttpURL());
		}
		if (this.getHttpAuthorization() != null) {
			apacheReq.setHeader("Authorization", this.getHttpAuthorization());
		}
		this.applyHeader(apacheReq);

		byte[] body = null;
		String contentType = null;
		if (apacheReq instanceof HttpPost) {
			HttpPost post = (HttpPost) apacheReq;
			if (post.getEntity() != null) {
				body = ByteStreams.toByteArray(post.getEntity().getContent());
				if (post.getEntity().getContentType() != null) {
					contentType = post.getEntity().getContentType().getValue();
				}
			}
		}

		okhttp3.Request.Builder rb = new okhttp3.Request.Builder().url(this.getHttpURL());
		for (Header h : apacheReq.getAllHeaders()) {
			if (h.getName().equalsIgnoreCase("Content-Type") || h.getName().equalsIgnoreCase("Content-Length")) continue;
			rb.header(h.getName(), h.getValue());
		}
		if (apacheReq instanceof HttpPost) {
			MediaType mt = contentType != null ? MediaType.parse(contentType) : MediaType.parse("application/json; charset=utf-8");
			RequestBody rbody = RequestBody.create(body != null ? body : new byte[0], mt);
			rb.post(rbody);
		} else {
			rb.get();
		}

		OkHttpClient http = client != null ? client : new OkHttpClient();
		try (okhttp3.Response resp = http.newCall(rb.build()).execute()) {
			String respBody = resp.body() != null ? resp.body().string() : "";
			if (resp.code() != 200) {
				try {
					System.out.println(respBody);
				} catch (Exception ignore) {
				}
				String excerpt = respBody.length() > 400 ? respBody.substring(0, 400) : respBody;
				throw new IllegalStateException("status code: " + resp.code() + " body: " + excerpt);
			}
			R decoded = GsonUtil.GSON.fromJson(respBody, this.getResponseClass());
			if (decoded instanceof APIResponseExt) {
				String sessionId = resp.header("X-SessionId");
				if (sessionId != null) {
					((APIResponseExt) decoded).applyResponse(fakeResponseWithSession(sessionId));
				}
			}
			return decoded;
		}
	}

	private static HttpResponse fakeResponseWithSession(final String sessionId) {
		final BasicHeader h = new BasicHeader("X-SessionId", sessionId);
		final Header[] arr = new Header[]{h};
		return (HttpResponse) Proxy.newProxyInstance(APIRequest.class.getClassLoader(),
				new Class[]{HttpResponse.class},
				(proxy, method, args) -> {
					String name = method.getName();
					if (name.equals("getFirstHeader")) return h;
					if (name.equals("getHeaders") || name.equals("getAllHeaders")) return arr;
					Class<?> rt = method.getReturnType();
					if (rt == boolean.class) return false;
					if (rt == int.class) return 0;
					if (rt == long.class) return 0L;
					return null;
				});
	}

	public abstract String getHttpURL();

	public String getHttpAuthorization() {
		return null;
	}

	public abstract APIEncoding getRequestEncoding();

	public abstract APIEncoding getResponseEncoding();

	public abstract Class<R> getResponseClass();

}
