package coelho.msftauth.api.xbox;

import coelho.msftauth.api.APIEncoding;
import coelho.msftauth.api.APIRequest;
import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;
import org.apache.http.HttpRequest;

public class XboxTitleAuthRequest extends APIRequest<XboxToken> {

	private static class Properties {
		@SerializedName("AuthMethod")
		public String authMethod;
		@SerializedName("SiteName")
		public String siteName;
		@SerializedName("RpsTicket")
		public String rpsTicket;
		@SerializedName("DeviceToken")
		public String deviceToken;
		@SerializedName("ProofKey")
		public XboxProofKey proofKey;
	}

	@SerializedName("RelyingParty")
	private String relyingParty;
	@SerializedName("TokenType")
	private String tokenType;
	@SerializedName("Properties")
	private Properties properties = new Properties();
	private transient String userHash;
	private transient String userToken;
	private transient XboxDeviceKey deviceKey;

	public XboxTitleAuthRequest(String accessToken, XboxToken userToken, XboxDeviceToken deviceToken, XboxDeviceKey key) {
		this.relyingParty = "http://auth.xboxlive.com";
		this.tokenType = "JWT";
		this.properties.authMethod = "RPS";
		this.properties.siteName = "user.auth.xboxlive.com";
		this.properties.rpsTicket = "t=" + accessToken;
		this.properties.deviceToken = deviceToken.getToken();
		this.properties.proofKey = key.getProofKey();
		JsonElement xui = userToken.getDisplayClaims().get("xui");
		this.userHash = xui.getAsJsonArray().get(0).getAsJsonObject().get("uhs").getAsString();
		this.userToken = userToken.getToken();
		this.deviceKey = key;
	}

	@Override
	public void applyHeader(HttpRequest request) {
		request.setHeader("Authorization", "XBL3.0 x=" + userHash + ";" + userToken);
		request.setHeader("x-xbl-contract-version", "1");
		this.deviceKey.sign(request);
	}

	@Override
	public String getHttpURL() {
		return "https://title.auth.xboxlive.com/title/authenticate";
	}

	@Override
	public APIEncoding getRequestEncoding() {
		return APIEncoding.JSON;
	}

	@Override
	public APIEncoding getResponseEncoding() {
		return APIEncoding.JSON;
	}

	@Override
	public Class<XboxToken> getResponseClass() {
		return XboxToken.class;
	}
}
