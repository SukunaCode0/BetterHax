package dev.sora.relay.session.listener.xbox

import com.google.gson.JsonParser
import dev.sora.relay.utils.HttpUtils
import okhttp3.FormBody
import okhttp3.Request


data class XboxDeviceInfo(val appId: String, val deviceType: String,
					  val allowDirectTitleTokenFetch: Boolean = false,
					  val xalRedirect: String = "") {

	fun refreshToken(token: String): Pair<String, String> {
		val clean = token.split("\n")[0].trim()
		val looksLikeAuthCode = isAuthCode(clean)
		val order = if (looksLikeAuthCode) listOf(true, false) else listOf(false, true)
		var lastErr: String? = null
		for (isCode in order) {
			val form = FormBody.Builder()
			form.add("client_id", appId)
			form.add("redirect_uri", "https://login.live.com/oauth20_desktop.srf")
			if (isCode) {
				form.add("grant_type", "authorization_code")
				form.add("code", clean)
			} else {
				form.add("scope", "service::user.auth.xboxlive.com::MBI_SSL")
				form.add("grant_type", "refresh_token")
				form.add("refresh_token", clean)
			}
			val request = Request.Builder()
				.url("https://login.live.com/oauth20_token.srf")
				.header("Content-Type", "application/x-www-form-urlencoded")
				.post(form.build())
				.build()
			val response = HttpUtils.client.newCall(request).execute()
			val bodyStr = try { response.body!!.string() } catch (t: Throwable) { "" }
			if (response.code == 200) {
				val body = JsonParser.parseString(bodyStr).asJsonObject
				if (!body.has("access_token") || !body.has("refresh_token")) {
					if (body.has("error")) {
						throw RuntimeException("error whilst refreshing token: " + body.get("error").asString + " " + bodyStr.take(500))
					} else {
						throw RuntimeException("error whilst refreshing token: " + bodyStr.take(500))
					}
				}
				return body.get("access_token").asString to body.get("refresh_token").asString
			}
			lastErr = bodyStr.take(500)
			val retryable = response.code == 400 && bodyStr.contains("invalid_grant")
			if (!retryable) {
					throw RuntimeException("login.live.com rejected token (Http " + response.code + "): " + bodyStr.take(500) + " -- auth codes expire in minutes and are single-use; sign in again fresh. If it persists your account may need app-password/2FA approval in a browser.")
			}
		}
		throw RuntimeException("login.live.com rejected code (Http 400): " + (lastErr ?: "") + " -- code expired/reused or wrong grant type; press back and sign in again from scratch (do not reuse the page).")
	}

	private fun isAuthCode(t: String): Boolean {
		if (t.startsWith("M.")) return t.length < 1200
		return t.substring(t.lastIndexOf('.') + 1).length == 36
	}

	companion object {

		val DEVICE_ANDROID = XboxDeviceInfo("0000000048183522", "Android", false, xalRedirect = "ms-xal-0000000048183522://auth")
		val DEVICE_IOS = XboxDeviceInfo("000000004c17c01a", "iOS", false, xalRedirect = "ms-xal-000000004c17c01a://auth")
		val DEVICE_NINTENDO = XboxDeviceInfo("00000000441cc96b", "Nintendo", true)
		val devices = arrayOf(DEVICE_ANDROID, DEVICE_IOS, DEVICE_NINTENDO).associateBy { it.deviceType }
	}
}
